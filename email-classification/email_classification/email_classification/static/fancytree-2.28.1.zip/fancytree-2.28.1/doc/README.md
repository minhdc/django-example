*Class API Reference for the [Fancytree JavaScript tree view / tree grid](https://github.com/mar10/fancytree/).*

See also the [Fancytree Documentation Wiki](https://github.com/mar10/fancytree/wiki/).
